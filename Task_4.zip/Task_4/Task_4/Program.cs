﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Drawing;
using System.Data;

namespace TimeSharedComputerSimulation
{
    // Event types
    public enum EventType
    {
        JobArrival = 1,
        EndCPURun = 2,
        EndSimulation = 3
    }

    // Scheduling policies
    public enum SchedulingPolicy
    {
        RoundRobin,
        ShortestJobFirst
    }

    // Discrete Distribution class
    public class DiscreteDistribution
    {
        private List<double> values;
        private List<double> probabilities;
        private List<double> cumulativeProbabilities;
        private Random random;

        public DiscreteDistribution(List<double> values, List<double> probabilities, Random random)
        {
            if (values.Count != probabilities.Count)
                throw new ArgumentException("Values and probabilities must have the same length");

            double sum = probabilities.Sum();
            if (Math.Abs(sum - 1.0) > 0.001)
                throw new ArgumentException($"Probabilities must sum to 1.0 (current sum: {sum})");

            this.values = new List<double>(values);
            this.probabilities = new List<double>(probabilities);
            this.random = random;

            // Calculate cumulative probabilities
            cumulativeProbabilities = new List<double>();
            double cumulative = 0;
            foreach (var prob in probabilities)
            {
                cumulative += prob;
                cumulativeProbabilities.Add(cumulative);
            }
        }

        public double Generate()
        {
            double r = random.NextDouble();
            for (int i = 0; i < cumulativeProbabilities.Count; i++)
            {
                if (r <= cumulativeProbabilities[i])
                    return values[i];
            }
            return values[values.Count - 1];
        }
    }

    // Job class
    public class Job
    {
        public int JobId { get; set; }
        public double ArrivalTime { get; set; }
        public double RemainingServiceTime { get; set; }
        public double StartTime { get; set; } // arrival/start of job in system
        public double OriginalServiceTime { get; set; } // store initial service time for wait calculation
    }

    // Event class
    public class Event : IComparable<Event>
    {
        public double Time { get; set; }
        public EventType Type { get; set; }
        public Job Job { get; set; }

        public int CompareTo(Event other)
        {
            return Time.CompareTo(other.Time);
        }
    }

    // Simulation Engine
    public class SimulationEngine
    {
        private Random thinkRandom;
        private Random serviceRandom;
        private SortedSet<Event> eventList;
        private Queue<Job> jobQueue;
        private Job currentJob;

        // Parameters
        public DiscreteDistribution ThinkTimeDistribution { get; set; }
        public DiscreteDistribution ServiceTimeDistribution { get; set; }
        public double Quantum { get; set; } = 0.1;
        public double SwapTime { get; set; } = 0.001;
        public int NumberOfTerminals { get; set; } = 10;
        public SchedulingPolicy Policy { get; set; } = SchedulingPolicy.RoundRobin;

        // Statistics
        private double currentTime;
        private int jobsCompleted;
        private int nextJobId;
        private double totalResponseTime;
        private double areaUnderQueueCurve;
        private double lastEventTime;
        private double totalBusyTime;
        private double cpuBusyStartTime;
        private List<double> responseTimes;

        // Wait time statistics (added)
        private double totalWaitTime;
        private List<double> waitTimes;

        public SimulationEngine()
        {
            thinkRandom = new Random(12345);
            serviceRandom = new Random(54321);
            eventList = new SortedSet<Event>();
            jobQueue = new Queue<Job>();
            responseTimes = new List<double>();

            // initialize wait-time lists
            waitTimes = new List<double>();
        }

        public SimulationResults Run()
        {
            Initialize();

            while (eventList.Count > 0)
            {
                Event currentEvent = eventList.First();
                eventList.Remove(currentEvent);

                // Update queue statistics
                UpdateQueueStatistics(currentEvent.Time);
                currentTime = currentEvent.Time;

                switch (currentEvent.Type)
                {
                    case EventType.JobArrival:
                        ProcessArrival(currentEvent.Job);
                        break;
                    case EventType.EndCPURun:
                        ProcessEndCPURun(currentEvent.Job);
                        break;
                    case EventType.EndSimulation:
                        return GenerateResults();
                }
            }

            return GenerateResults();
        }

        private void Initialize()
        {
            currentTime = 0.0;
            jobsCompleted = 0;
            nextJobId = 0;
            totalResponseTime = 0.0;
            areaUnderQueueCurve = 0.0;
            lastEventTime = 0.0;
            totalBusyTime = 0.0;
            cpuBusyStartTime = -1;
            currentJob = null;
            eventList.Clear();
            jobQueue.Clear();
            responseTimes.Clear();

            // Initialize wait-time statistics
            totalWaitTime = 0.0;
            waitTimes = new List<double>();

            // Schedule initial arrivals for all terminals
            for (int i = 0; i < NumberOfTerminals; i++)
            {
                double thinkTime = ThinkTimeDistribution.Generate();
                double service = ServiceTimeDistribution.Generate();

                Job job = new Job
                {
                    JobId = nextJobId++,
                    ArrivalTime = thinkTime,
                    RemainingServiceTime = service,
                    OriginalServiceTime = service,
                    StartTime = thinkTime
                };

                eventList.Add(new Event
                {
                    Time = thinkTime,
                    Type = EventType.JobArrival,
                    Job = job
                });
            }
        }

        private void ProcessArrival(Job job)
        {
            if (Policy == SchedulingPolicy.ShortestJobFirst)
            {
                var tempList = jobQueue.ToList();
                tempList.Add(job);
                jobQueue = new Queue<Job>(tempList.OrderBy(j => j.RemainingServiceTime));
            }
            else
            {
                jobQueue.Enqueue(job);
            }

            if (currentJob == null)
            {
                StartCPURun();
            }
        }

        private void StartCPURun()
        {
            if (jobQueue.Count == 0) return;

            currentJob = jobQueue.Dequeue();

            if (cpuBusyStartTime < 0)
            {
                cpuBusyStartTime = currentTime;
            }

            double runTime;
            if (currentJob.RemainingServiceTime <= Quantum)
            {
                runTime = currentJob.RemainingServiceTime + SwapTime;
            }
            else
            {
                runTime = Quantum + SwapTime;
            }

            eventList.Add(new Event
            {
                Time = currentTime + runTime,
                Type = EventType.EndCPURun,
                Job = currentJob
            });
        }

        private void ProcessEndCPURun(Job job)
        {
            // Determine whether job completes in this run or needs more processing.
            if (job.RemainingServiceTime <= Quantum)
            {
                // Job completed
                jobsCompleted++;

                double responseTime = currentTime - job.StartTime; // total time in system
                totalResponseTime += responseTime;
                responseTimes.Add(responseTime);

                // Calculate wait time using the stored original service time:
                double waitTime = responseTime - job.OriginalServiceTime;
                if (waitTime < 0) waitTime = 0; // guard against numerical rounding
                totalWaitTime += waitTime;
                waitTimes.Add(waitTime);

                // Check if simulation should end (all jobs completed)
                if (jobsCompleted >= NumberOfTerminals)
                {
                    if (cpuBusyStartTime >= 0)
                    {
                        totalBusyTime += (currentTime - cpuBusyStartTime);
                    }
                    eventList.Clear();
                    eventList.Add(new Event
                    {
                        Time = currentTime,
                        Type = EventType.EndSimulation
                    });
                    return;
                }
            }
            else
            {
                // Job needs more processing
                job.RemainingServiceTime -= Quantum;

                if (Policy == SchedulingPolicy.ShortestJobFirst)
                {
                    var tempList = jobQueue.ToList();
                    tempList.Add(job);
                    jobQueue = new Queue<Job>(tempList.OrderBy(j => j.RemainingServiceTime));
                }
                else
                {
                    jobQueue.Enqueue(job);
                }
            }

            if (cpuBusyStartTime >= 0)
            {
                totalBusyTime += (currentTime - cpuBusyStartTime);
                cpuBusyStartTime = -1;
            }

            currentJob = null;
            StartCPURun();
        }

        private void UpdateQueueStatistics(double newTime)
        {
            double timeSinceLastEvent = newTime - lastEventTime;
            areaUnderQueueCurve += jobQueue.Count * timeSinceLastEvent;
            lastEventTime = newTime;
        }

        private SimulationResults GenerateResults()
        {
            return new SimulationResults
            {
                AverageResponseTime = jobsCompleted > 0 ? totalResponseTime / jobsCompleted : 0,
                AverageQueueLength = currentTime > 0 ? areaUnderQueueCurve / currentTime : 0,
                CPUUtilization = currentTime > 0 ? totalBusyTime / currentTime : 0,
                JobsCompleted = jobsCompleted,
                SimulationTime = currentTime,
                ResponseTimes = new List<double>(responseTimes),

                // Wait time results
                AverageWaitTime = jobsCompleted > 0 ? totalWaitTime / jobsCompleted : 0,
                WaitTimes = new List<double>(waitTimes)
            };
        }
    }

    // Results class
    public class SimulationResults
    {
        public double AverageResponseTime { get; set; }
        public double AverageQueueLength { get; set; }
        public double CPUUtilization { get; set; }
        public int JobsCompleted { get; set; }
        public double SimulationTime { get; set; }
        public List<double> ResponseTimes { get; set; }

        // Added fields for wait time
        public double AverageWaitTime { get; set; }
        public List<double> WaitTimes { get; set; }
    }

    // Main Form
    public class MainForm : Form
    {
        private DataGridView dgvThinkTime;
        private DataGridView dgvServiceTime;
        private NumericUpDown numTerminals;
        private NumericUpDown numQuantum;
        private NumericUpDown numStopCondition;
        private ComboBox cmbPolicy;
        private Button btnRun;
        // removed: btnRunMultiple, progressBar
        // Results UI controls
        private Panel resultsPanel;
        private Label lblResultsTitle;
        private Label lblTerminalsLabel;
        private Label lblTerminalsValue;
        private Label lblPolicyLabel;
        private Label lblPolicyValue;
        private Label lblJobsCompletedLabel;
        private Label lblJobsCompletedValue;
        private Label lblSimTimeLabel;
        private Label lblSimTimeValue;

        private Label lblAvgResponseLabel;
        private Label lblAvgResponseValue;
        private Label lblAvgWaitLabel;
        private Label lblAvgWaitValue;
        private Label lblAvgQueueLabel;
        private Label lblAvgQueueValue;
        private Label lblCPUUtilLabel;
        private Label lblCPUUtilValue;

        public MainForm()
        {
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            this.Text = "Time-Shared Computer Simulation";
            this.Size = new Size(1000, 800);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Create main panels
            Panel topPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 450,
                AutoScroll = true
            };

            Panel bottomPanel = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(10)
            };

            // Title
            Label lblTitle = new Label
            {
                Text = "Simulation Parameters",
                Font = new Font("Arial", 14, FontStyle.Bold),
                Location = new Point(10, 10),
                AutoSize = true
            };

            // Distribution panels
            GroupBox grpThink = new GroupBox
            {
                Text = "Think Times Distribution",
                Location = new Point(10, 45),
                Size = new Size(450, 250)
            };

            dgvThinkTime = new DataGridView
            {
                Location = new Point(10, 25),
                Size = new Size(430, 180),
                AllowUserToResizeRows = false,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            dgvThinkTime.Columns.Add(new DataGridViewTextBoxColumn { Name = "Value", HeaderText = "Value (seconds)" });
            dgvThinkTime.Columns.Add(new DataGridViewTextBoxColumn { Name = "Probability", HeaderText = "Probability" });

            // Add default values for think time
            dgvThinkTime.Rows.Add("20", "0.3");
            dgvThinkTime.Rows.Add("25", "0.4");
            dgvThinkTime.Rows.Add("30", "0.3");

            Button btnAddThink = new Button
            {
                Text = "Add Row",
                Location = new Point(10, 210),
                Size = new Size(100, 25)
            };
            btnAddThink.Click += (s, e) => dgvThinkTime.Rows.Add();

            Button btnRemoveThink = new Button
            {
                Text = "Remove Row",
                Location = new Point(120, 210),
                Size = new Size(100, 25)
            };
            btnRemoveThink.Click += (s, e) => {
                if (dgvThinkTime.SelectedRows.Count > 0 && dgvThinkTime.Rows.Count > 1)
                    dgvThinkTime.Rows.RemoveAt(dgvThinkTime.SelectedRows[0].Index);
            };

            grpThink.Controls.AddRange(new Control[] { dgvThinkTime, btnAddThink, btnRemoveThink });

            GroupBox grpService = new GroupBox
            {
                Text = "Service Times Distribution",
                Location = new Point(470, 45),
                Size = new Size(450, 250)
            };

            dgvServiceTime = new DataGridView
            {
                Location = new Point(10, 25),
                Size = new Size(430, 180),
                AllowUserToResizeRows = false,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            dgvServiceTime.Columns.Add(new DataGridViewTextBoxColumn { Name = "Value", HeaderText = "Value (seconds)" });
            dgvServiceTime.Columns.Add(new DataGridViewTextBoxColumn { Name = "Probability", HeaderText = "Probability" });

            // Add default values for service time
            dgvServiceTime.Rows.Add("0.5", "0.3");
            dgvServiceTime.Rows.Add("0.8", "0.5");
            dgvServiceTime.Rows.Add("1.0", "0.2");

            Button btnAddService = new Button
            {
                Text = "Add Row",
                Location = new Point(10, 210),
                Size = new Size(100, 25)
            };
            btnAddService.Click += (s, e) => dgvServiceTime.Rows.Add();

            Button btnRemoveService = new Button
            {
                Text = "Remove Row",
                Location = new Point(120, 210),
                Size = new Size(100, 25)
            };
            btnRemoveService.Click += (s, e) => {
                if (dgvServiceTime.SelectedRows.Count > 0 && dgvServiceTime.Rows.Count > 1)
                    dgvServiceTime.Rows.RemoveAt(dgvServiceTime.SelectedRows[0].Index);
            };

            grpService.Controls.AddRange(new Control[] { dgvServiceTime, btnAddService, btnRemoveService });

            // Other parameters
            Label lblTerminals = new Label { Text = "Number of Terminals:", Location = new Point(10, 310), AutoSize = true };
            numTerminals = new NumericUpDown
            {
                Location = new Point(200, 308),
                Width = 100,
                Minimum = 1,
                Maximum = 100,
                Value = 10
            };

            Label lblQuantum = new Label { Text = "Quantum Time (s):", Location = new Point(10, 340), AutoSize = true };
            numQuantum = new NumericUpDown
            {
                Location = new Point(200, 338),
                Width = 100,
                DecimalPlaces = 3,
                Minimum = 0.001M,
                Maximum = 10,
                Value = 0.1M,
                Increment = 0.01M
            };

            Label lblStop = new Label { Text = "Number of jobs:", Location = new Point(10, 370), AutoSize = true };
            numStopCondition = new NumericUpDown
            {
                Location = new Point(200, 368),
                Width = 100,
                Minimum = 1,
                Maximum = 100,
                Value = 10
            };

            Label lblPolicy = new Label { Text = "Scheduling Policy:", Location = new Point(10, 400), AutoSize = true };
            cmbPolicy = new ComboBox
            {
                Location = new Point(200, 398),
                Width = 150,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cmbPolicy.Items.AddRange(new object[] { "Round Robin", "Shortest Job First" });
            cmbPolicy.SelectedIndex = 0;

            btnRun = new Button
            {
                Text = "Run Single Simulation",
                Location = new Point(350, 308),
                Size = new Size(150, 35),
                Font = new Font("Arial", 9, FontStyle.Bold)
            };
            btnRun.Click += BtnRun_Click;

            // Results panel (replaces txtResults)
            resultsPanel = new Panel
            {
                Location = new Point(10, 35),
                Size = new Size(960, 280),
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.WhiteSmoke
            };

            // build labels inside resultsPanel using a table layout
            lblResultsTitle = new Label
            {
                Text = "SIMULATION RESULTS",
                Font = new Font("Arial", 12, FontStyle.Bold),
                Dock = DockStyle.Top,
                Height = 34,
                TextAlign = ContentAlignment.MiddleCenter
            };

            var table = new TableLayoutPanel
            {
                ColumnCount = 4,
                RowCount = 6,
                Dock = DockStyle.Fill,
                Padding = new Padding(10),
                AutoSize = false
            };

            // Columns: label | value | label | value
            table.ColumnStyles.Clear();
            table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30f)); // label
            table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20f)); // value
            table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30f)); // label
            table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20f)); // value

            for (int r = 0; r < 6; r++)
                table.RowStyles.Add(new RowStyle(SizeType.Percent, 100f / 6f));

            lblTerminalsLabel = new Label { Text = "Terminals:", Anchor = AnchorStyles.Left, AutoSize = true };
            lblTerminalsValue = new Label { Text = "-", Anchor = AnchorStyles.Left, AutoSize = true, Font = new Font("Consolas", 9, FontStyle.Bold) };

            lblPolicyLabel = new Label { Text = "Policy:", Anchor = AnchorStyles.Left, AutoSize = true };
            lblPolicyValue = new Label { Text = "-", Anchor = AnchorStyles.Left, AutoSize = true, Font = new Font("Consolas", 9, FontStyle.Bold) };

            lblJobsCompletedLabel = new Label { Text = "Jobs Completed:", Anchor = AnchorStyles.Left, AutoSize = true };
            lblJobsCompletedValue = new Label { Text = "-", Anchor = AnchorStyles.Left, AutoSize = true, Font = new Font("Consolas", 9, FontStyle.Bold) };

            lblSimTimeLabel = new Label { Text = "Simulation Time:", Anchor = AnchorStyles.Left, AutoSize = true };
            lblSimTimeValue = new Label { Text = "-", Anchor = AnchorStyles.Left, AutoSize = true, Font = new Font("Consolas", 9, FontStyle.Bold) };

            lblAvgResponseLabel = new Label { Text = "Average Response Time:", Anchor = AnchorStyles.Left, AutoSize = true };
            lblAvgResponseValue = new Label { Text = "-", Anchor = AnchorStyles.Left, AutoSize = true, Font = new Font("Consolas", 9, FontStyle.Bold) };

            lblAvgWaitLabel = new Label { Text = "Average Wait Time:", Anchor = AnchorStyles.Left, AutoSize = true };
            lblAvgWaitValue = new Label { Text = "-", Anchor = AnchorStyles.Left, AutoSize = true, Font = new Font("Consolas", 9, FontStyle.Bold) };

            lblAvgQueueLabel = new Label { Text = "Average Queue Length:", Anchor = AnchorStyles.Left, AutoSize = true };
            lblAvgQueueValue = new Label { Text = "-", Anchor = AnchorStyles.Left, AutoSize = true, Font = new Font("Consolas", 9, FontStyle.Bold) };

            lblCPUUtilLabel = new Label { Text = "CPU Utilization:", Anchor = AnchorStyles.Left, AutoSize = true };
            lblCPUUtilValue = new Label { Text = "-", Anchor = AnchorStyles.Left, AutoSize = true, Font = new Font("Consolas", 9, FontStyle.Bold) };

            // Fill table rows
            table.Controls.Add(lblTerminalsLabel, 0, 0);
            table.Controls.Add(lblTerminalsValue, 1, 0);
            table.Controls.Add(lblPolicyLabel, 2, 0);
            table.Controls.Add(lblPolicyValue, 3, 0);

            table.Controls.Add(lblJobsCompletedLabel, 0, 1);
            table.Controls.Add(lblJobsCompletedValue, 1, 1);
            table.Controls.Add(lblSimTimeLabel, 2, 1);
            table.Controls.Add(lblSimTimeValue, 3, 1);

            table.Controls.Add(lblAvgResponseLabel, 0, 2);
            table.Controls.Add(lblAvgResponseValue, 1, 2);
            table.Controls.Add(lblAvgWaitLabel, 2, 2);
            table.Controls.Add(lblAvgWaitValue, 3, 2);

            table.Controls.Add(lblAvgQueueLabel, 0, 3);
            table.Controls.Add(lblAvgQueueValue, 1, 3);
            table.Controls.Add(lblCPUUtilLabel, 2, 3);
            table.Controls.Add(lblCPUUtilValue, 3, 3);

            // Add title and table to resultsPanel
            resultsPanel.Controls.Add(table);
            resultsPanel.Controls.Add(lblResultsTitle);

            // Add controls to panels
            topPanel.Controls.AddRange(new Control[] {
                lblTitle, grpThink, grpService,
                lblTerminals, numTerminals, lblQuantum, numQuantum,
                lblStop, numStopCondition, lblPolicy, cmbPolicy,
                btnRun
            });

            bottomPanel.Controls.Add(resultsPanel);

            this.Controls.Add(bottomPanel);
            this.Controls.Add(topPanel);
        }

        private bool ValidateDistribution(DataGridView dgv, out List<double> values, out List<double> probabilities, out string errorMsg)
        {
            values = new List<double>();
            probabilities = new List<double>();
            errorMsg = "";

            foreach (DataGridViewRow row in dgv.Rows)
            {
                if (row.IsNewRow) continue;

                if (row.Cells[0].Value == null || row.Cells[1].Value == null)
                {
                    errorMsg = "All cells must have values";
                    return false;
                }

                if (!double.TryParse(row.Cells[0].Value.ToString(), out double val))
                {
                    errorMsg = "Invalid value in distribution";
                    return false;
                }

                if (!double.TryParse(row.Cells[1].Value.ToString(), out double prob))
                {
                    errorMsg = "Invalid probability in distribution";
                    return false;
                }

                if (prob < 0 || prob > 1)
                {
                    errorMsg = "Probabilities must be between 0 and 1";
                    return false;
                }

                values.Add(val);
                probabilities.Add(prob);
            }

            if (values.Count == 0)
            {
                errorMsg = "Distribution must have at least one value";
                return false;
            }

            double sum = probabilities.Sum();
            if (Math.Abs(sum - 1.0) > 0.001)
            {
                errorMsg = $"Probabilities must sum to 1.0 (current sum: {sum:F4})";
                return false;
            }

            return true;
        }

        private void BtnRun_Click(object sender, EventArgs e)
        {
            btnRun.Enabled = false;

            try
            {
                // Validate distributions
                if (!ValidateDistribution(dgvThinkTime, out var thinkValues, out var thinkProbs, out string thinkError))
                {
                    MessageBox.Show($"Think Time Distribution Error: {thinkError}", "Validation Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (!ValidateDistribution(dgvServiceTime, out var serviceValues, out var serviceProbs, out string serviceError))
                {
                    MessageBox.Show($"Service Time Distribution Error: {serviceError}", "Validation Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                SimulationEngine engine = new SimulationEngine
                {
                    NumberOfTerminals = (int)numTerminals.Value,
                    ThinkTimeDistribution = new DiscreteDistribution(thinkValues, thinkProbs, new Random(12345)),
                    ServiceTimeDistribution = new DiscreteDistribution(serviceValues, serviceProbs, new Random(54321)),
                    Quantum = (double)numQuantum.Value,
                    Policy = cmbPolicy.SelectedIndex == 0 ? SchedulingPolicy.RoundRobin : SchedulingPolicy.ShortestJobFirst
                };

                SimulationResults results = engine.Run();
                DisplayResults(results, (int)numTerminals.Value);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Simulation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                btnRun.Enabled = true;
            }
        }

        private void DisplayResults(SimulationResults results, int terminals)
        {
            // update header values
            lblTerminalsValue.Text = terminals.ToString();
            lblPolicyValue.Text = cmbPolicy.Text;
            lblJobsCompletedValue.Text = results.JobsCompleted.ToString();
            lblSimTimeValue.Text = $"{results.SimulationTime:F2} s";

            // update metrics
            lblAvgResponseValue.Text = $"{results.AverageResponseTime:F4} s";
            lblAvgWaitValue.Text = $"{results.AverageWaitTime:F4} s";
            lblAvgQueueValue.Text = $"{results.AverageQueueLength:F4}";
            lblCPUUtilValue.Text = $"{results.CPUUtilization * 100:F2} %";

            // visual cue for meeting requirement
            if (results.AverageResponseTime <= 30.0)
            {
                lblResultsTitle.Text = "SIMULATION RESULTS — ✓ Meets 30s Requirement";
                lblResultsTitle.ForeColor = Color.DarkGreen;
            }
            else
            {
                lblResultsTitle.Text = "SIMULATION RESULTS — ✗ Exceeds 30s Requirement";
                lblResultsTitle.ForeColor = Color.DarkRed;
            }
        }

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
